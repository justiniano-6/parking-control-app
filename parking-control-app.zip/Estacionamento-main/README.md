# Estacionamento
Controle de acesso de veículos, entrada e saída com leitura de QrCode
